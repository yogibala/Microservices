INSERT INTO employee (name, salary) VALUES ('Amy', 3500.0);
INSERT INTO employee (name, salary) VALUES ('Jake', 4000.0);
INSERT INTO employee (name, salary) VALUES ('Charles', 3000.0);
INSERT INTO employee (name, salary) VALUES ('Terry', 5500.0);
INSERT INTO employee (name, salary) VALUES ('Rosa', 5000.0);

insert into student values(10001,'Ramesh', 'E1234567');
insert into student values(10002,'Kemparaj', 'A1234568');